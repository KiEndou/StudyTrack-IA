const apiUrl = import.meta.env.VITE_API_URL || "http://localhost:8000/api";

export async function checkApiHealth(): Promise<void> {
  const response = await fetch(`${apiUrl}/health`);
  if (!response.ok) throw new Error("API indisponível");
}

export type TutorMessage = { role: "user" | "assistant"; content: string };
export type TutorReply = { reply: string; model: string };

export async function sendTutorMessage(
  token: string,
  message: string,
  history: TutorMessage[] = []
): Promise<TutorReply> {
  const response = await fetch(`${apiUrl}/tutor/chat`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
    body: JSON.stringify({ message, history: history.slice(-12) }),
  });
  if (!response.ok) {
    const errorBody = (await response.json().catch(() => null)) as { detail?: string } | null;
    throw new Error(errorBody?.detail || `Falha no Tutor (HTTP ${response.status})`);
  }
  return (await response.json()) as TutorReply;
}

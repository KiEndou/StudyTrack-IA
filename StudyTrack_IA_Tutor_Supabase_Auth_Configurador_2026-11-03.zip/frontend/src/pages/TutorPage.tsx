import { useState, type FormEvent } from "react";
import { AppLayout, Icon } from "../components/AppLayout";
import { useAuth } from "../contexts/AuthContext";
import { sendTutorMessage, type TutorMessage } from "../services/api";
import "./TutorPage.css";

export function TutorPage() {
  const { session } = useAuth();
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<TutorMessage[]>([]);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState("");

  async function handleSend(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const message = input.trim();
    if (!message || sending) return;
    if (!session?.access_token) {
      setError("Faça login novamente para usar o Tutor.");
      return;
    }
    const history = messages.slice(-12);
    setMessages((previous) => [...previous, { role: "user", content: message }]);
    setInput("");
    setError("");
    setSending(true);
    try {
      const answer = await sendTutorMessage(session.access_token, message, history);
      setMessages((previous) => [...previous, { role: "assistant", content: answer.reply }]);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Não foi possível consultar o Tutor.");
    } finally {
      setSending(false);
    }
  }

  return (
    <AppLayout>
      <div className="tutor-page">
        <section className="tutor-intro">
          <div>
            <p className="eyebrow">APOIO PARA SUA JORNADA</p>
            <h1>Tutor StudyTrack</h1>
            <p className="tutor-description">Um espaço para tirar dúvidas, revisar conteúdos e receber apoio nos estudos.</p>
          </div>
          <span className="tutor-status"><i /> {session ? "Sessão ativa" : "Login necessário"}</span>
        </section>
        <section className="tutor-welcome-card">
          <div className="tutor-orbit">
            <div className="tutor-orbit-inner"><Icon name="sparkles" size={29} /></div>
            <span /><span /><span />
          </div>
          <div className="tutor-welcome-copy">
            <span className="tutor-kicker">SEU PARCEIRO DE ESTUDOS</span>
            <h2>Aprender fica mais leve quando você tem com quem conversar.</h2>
            <p>Converse sobre conteúdos, peça exemplos e explore explicações de forma interativa, no seu ritmo.</p>
            <div className="tutor-feature-list">
              <span><Icon name="message" size={15} /> Conversas e dúvidas</span>
              <span><Icon name="book" size={15} /> Apoio nos conteúdos</span>
              <span><Icon name="lightbulb" size={15} /> Ideias e explicações</span>
            </div>
          </div>
        </section>
        <section className="tutor-chat-shell" aria-label="Área de conversa com o Tutor StudyTrack">
          <div className="tutor-chat-heading">
            <div className="tutor-chat-avatar"><Icon name="sparkles" size={17} /></div>
            <div><strong>Tutor StudyTrack</strong><span>Assistente de estudos</span></div>
            <span className="tutor-coming-soon">CHAT</span>
          </div>
          <div className="tutor-chat-body tutor-chat-messages" role="log" aria-live="polite">
            <div className="tutor-chat-row">
              <div className="tutor-message-avatar"><Icon name="sparkles" size={18} /></div>
              <div className="tutor-message-content"><span>Tutor StudyTrack</span><p>Olá! O que você gostaria de aprender hoje?</p></div>
            </div>
            {messages.map((item, index) => (
              <div className={`tutor-chat-row ${item.role === "user" ? "tutor-chat-user" : ""}`} key={index}>
                {item.role === "assistant" && <div className="tutor-message-avatar"><Icon name="sparkles" size={18} /></div>}
                <div className="tutor-message-content">
                  <span>{item.role === "user" ? "Você" : "Tutor StudyTrack"}</span>
                  <p>{item.content}</p>
                </div>
              </div>
            ))}
            {sending && <p className="tutor-typing" role="status">Tutor preparando resposta...</p>}
          </div>
          {error && <p className="tutor-chat-error" role="alert">{error}</p>}
          <form className="tutor-composer" onSubmit={handleSend}>
            <input
              type="text"
              value={input}
              onChange={(event) => setInput(event.target.value)}
              placeholder={session ? "Digite sua dúvida..." : "Faça login para conversar..."}
              disabled={!session || sending}
              maxLength={4000}
              aria-label="Mensagem ao Tutor StudyTrack"
            />
            <button type="submit" disabled={!session || sending || !input.trim()} aria-label="Enviar mensagem">
              <Icon name="arrow-up" size={17} />
            </button>
          </form>
          <p className="tutor-disclaimer"><Icon name="info" size={13} /> Respostas de IA podem conter erros. Confira informações importantes em fontes confiáveis.</p>
        </section>
      </div>
    </AppLayout>
  );
}

from pydantic import BaseModel, ConfigDict, EmailStr


class UserBase(BaseModel):
    email: EmailStr | None = None
    full_name: str | None = None


class UserCreate(UserBase):
    pass


class UserResponse(UserBase):
    id: str
    model_config = ConfigDict(from_attributes=True)

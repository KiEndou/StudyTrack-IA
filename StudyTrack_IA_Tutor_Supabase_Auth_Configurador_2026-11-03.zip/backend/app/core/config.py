"""Configurações carregadas de variáveis de ambiente e do .env privado da raiz."""
from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

_ROOT = Path(__file__).resolve().parents[3]


class Settings(BaseSettings):
    app_name: str = "StudyTrack IA API"
    database_url: str = ""
    supabase_url: str = ""
    supabase_service_role_key: str = ""  # Mantido para compatibilidade; Tutor NÃO usa.
    supabase_publishable_key: str = ""
    groq_api_key: str = ""
    groq_model: str = "openai/gpt-oss-120b"
    cors_origins: list[str] = ["http://localhost:5173"]

    model_config = SettingsConfigDict(env_file=str(_ROOT / ".env"), extra="ignore")


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()

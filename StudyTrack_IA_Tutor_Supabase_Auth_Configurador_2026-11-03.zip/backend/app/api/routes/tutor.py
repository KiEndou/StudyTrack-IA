"""Tutor StudyTrack: autenticação Supabase Auth + geração Groq.

Não utiliza chave service-role; valida a sessão diretamente no endpoint /auth/v1/user.
"""
from __future__ import annotations

import httpx
from fastapi import APIRouter, Header, HTTPException
from pydantic import BaseModel, Field

from app.core.config import settings

router = APIRouter()

SYSTEM_PROMPT = (
    "Você é o Tutor StudyTrack IA, um assistente acadêmico em português brasileiro. "
    "Explique assuntos de maneira clara, com exemplos e perguntas que estimulem o aprendizado. "
    "Não invente fontes, notas, informações pessoais ou resultados. "
    "Quando não souber, informe a incerteza. Não solicite senhas nem tokens."
)


class HistoryMessage(BaseModel):
    role: str = Field(pattern=r"^(user|assistant)$")
    content: str = Field(min_length=1, max_length=4000)


class TutorRequest(BaseModel):
    message: str = Field(min_length=1, max_length=4000)
    history: list[HistoryMessage] = Field(default_factory=list, max_length=12)


class TutorResponse(BaseModel):
    reply: str
    model: str


async def verify_supabase_user(access_token: str) -> dict:
    """Consulta real à API de Auth do Supabase para validar o access_token."""
    if not settings.supabase_url or not settings.supabase_publishable_key:
        raise HTTPException(status_code=503, detail="Autenticação não configurada no servidor.")
    try:
        async with httpx.AsyncClient(timeout=12) as client:
            response = await client.get(
                f"{settings.supabase_url.rstrip('/')}/auth/v1/user",
                headers={
                    "apikey": settings.supabase_publishable_key,
                    "Authorization": f"Bearer {access_token}",
                },
            )
    except httpx.RequestError:
        raise HTTPException(status_code=502, detail="Não foi possível validar a sessão.") from None
    if response.status_code in (401, 403):
        raise HTTPException(status_code=401, detail="Sessão inválida ou expirada.")
    if response.status_code != 200:
        raise HTTPException(status_code=502, detail="Falha ao consultar a autenticação.")
    try:
        user = response.json()
    except ValueError:
        raise HTTPException(status_code=502, detail="Resposta de autenticação inválida.") from None
    if not isinstance(user, dict) or not user.get("id"):
        raise HTTPException(status_code=401, detail="Usuário não autenticado.")
    return user


async def ask_groq(message: str, history: list[HistoryMessage]) -> str:
    """Faz uma chamada real a Groq, usando chave acessível somente no backend."""
    if not settings.groq_api_key:
        raise HTTPException(status_code=503, detail="Tutor indisponível: Groq não configurada.")
    messages = [{"role": "system", "content": SYSTEM_PROMPT}]
    messages += [item.model_dump() for item in history]
    messages.append({"role": "user", "content": message})
    try:
        async with httpx.AsyncClient(timeout=35) as client:
            response = await client.post(
                "https://api.groq.com/openai/v1/chat/completions",
                headers={"Authorization": f"Bearer {settings.groq_api_key}"},
                json={
                    "model": settings.groq_model,
                    "messages": messages,
                    "temperature": 0.4,
                    "max_completion_tokens": 700,
                },
            )
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="A resposta do Tutor demorou além do limite.") from None
    except httpx.RequestError:
        raise HTTPException(status_code=502, detail="Não foi possível consultar o modelo.") from None
    if response.status_code != 200:
        # Não propagar respostas externas: podem conter detalhes sensíveis.
        raise HTTPException(status_code=502, detail="Falha na geração da resposta pelo modelo.")
    try:
        data = response.json()
        answer = data["choices"][0]["message"]["content"]
        if not isinstance(answer, str) or not answer.strip():
            raise (ValueError("empty response"))
        return answer.strip()
    except (KeyError, IndexError, TypeError, ValueError):
        raise HTTPException(status_code=502, detail="Resposta inválida do modelo.") from None


@router.post("/chat", response_model=TutorResponse)
async def tutor_chat(
    payload: TutorRequest,
    authorization: str | None = Header(default=None),
) -> TutorResponse:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="Faça login para acessar o Tutor.")
    access_token = authorization.split(" ", 1)[1].strip()
    if not access_token:
        raise HTTPException(status_code=401, detail="Sessão ausente.")
    await verify_supabase_user(access_token)
    reply = await ask_groq(payload.message, payload.history)
    return TutorResponse(reply=reply, model=settings.groq_model)

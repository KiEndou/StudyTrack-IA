from fastapi import APIRouter
from app.schemas.user import UserResponse
router = APIRouter()


@router.get("/me", response_model=UserResponse)
def get_current_user() -> UserResponse:
    return UserResponse(id="pending-auth", email=None, full_name=None)

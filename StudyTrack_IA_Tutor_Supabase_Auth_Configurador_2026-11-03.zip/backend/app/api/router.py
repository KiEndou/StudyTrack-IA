# Centraliza os grupos de rotas expostos pelo backend.
from fastapi import APIRouter

from app.api.routes.health import router as health_router
from app.api.routes.users import router as users_router
from app.api.routes.tutor import router as tutor_router

api_router = APIRouter()
api_router.include_router(health_router, tags=["health"])
api_router.include_router(users_router, prefix="/users", tags=["users"])
api_router.include_router(tutor_router, prefix="/tutor", tags=["tutor"])

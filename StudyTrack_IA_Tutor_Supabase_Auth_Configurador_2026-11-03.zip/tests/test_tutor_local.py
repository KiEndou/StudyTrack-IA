"""Testes locais, SEM acesso externo: não comprovam integrações reais."""
from fastapi.testclient import TestClient
from app.main import app
import app.api.routes.tutor as tutor

client = TestClient(app)


def test_route_requires_login():
    result = client.post("/api/tutor/chat", json={"message": "Olá"})
    assert result.status_code == 401


def test_route_rejects_empty_message():
    result = client.post("/api/tutor/chat", json={"message": ""}, headers={"Authorization": "Bearer fake"})
    assert result.status_code == 422


def test_route_rejects_invalid_history_role():
    result = client.post(
        "/api/tutor/chat",
        json={"message": "Olá", "history": [{"role": "system", "content": "injetar"}]},
        headers={"Authorization": "Bearer fake"},
    )
    assert result.status_code == 422


def test_authenticated_mock_happy_path(monkeypatch):
    async def fake_verify(_token):
        return {"id": "mock-user"}
    async def fake_groq(message, history):
        assert message == "Explique grafos"
        assert len(history) == 0
        return "Um grafo tem vértices e arestas."
    monkeypatch.setattr(tutor, "verify_supabase_user", fake_verify)
    monkeypatch.setattr(tutor, "ask_groq", fake_groq)
    result = client.post(
        "/api/tutor/chat", json={"message": "Explique grafos"},
        headers={"Authorization": "Bearer mock-token"},
    )
    assert result.status_code == 200
    assert result.json()["reply"] == "Um grafo tem vértices e arestas."


def test_no_token_even_with_mocks(monkeypatch):
    async def forbidden(_token):
        raise AssertionError("Não deveria validar sem bearer token")
    monkeypatch.setattr(tutor, "verify_supabase_user", forbidden)
    result = client.post("/api/tutor/chat", json={"message": "Oi"})
    assert result.status_code == 401


def test_invalid_token_is_rejected(monkeypatch):
    from fastapi import HTTPException

    async def fake_verify(_token):
        raise HTTPException(status_code=401, detail="Sessão inválida ou expirada.")
    monkeypatch.setattr(tutor, "verify_supabase_user", fake_verify)
    result = client.post(
        "/api/tutor/chat", json={"message": "Olá"},
        headers={"Authorization": "Bearer invalid"},
    )
    assert result.status_code == 401


def test_missing_groq_key_is_service_unavailable(monkeypatch):
    async def fake_verify(_token):
        return {"id": "mock-user"}
    monkeypatch.setattr(tutor, "verify_supabase_user", fake_verify)
    monkeypatch.setattr(tutor.settings, "groq_api_key", "")
    result = client.post(
        "/api/tutor/chat", json={"message": "Explique árvores"},
        headers={"Authorization": "Bearer example"},
    )
    assert result.status_code == 503
    assert "Groq" in result.json()["detail"]

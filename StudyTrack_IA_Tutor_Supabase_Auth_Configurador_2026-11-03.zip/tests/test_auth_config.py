"""Testes LOCAIS do configurador. Nunca acessam o Supabase/Groq reais."""

import httpx
import pytest
from dotenv import dotenv_values

from scripts.configurar_auth_teste import (
    ConfigError,
    create_user,
    save_env,
    validate_groq,
    verify_user,
)


def _client(handler):
    return httpx.Client(transport=httpx.MockTransport(handler), timeout=5)


def test_create_test_user_via_auth_signup_official():
    def handler(request):
        assert request.url.path.endswith('/auth/v1/signup')
        assert request.headers['apikey'] == 'sb_publishable_example'
        assert b'@example.org' in request.content
        return httpx.Response(200, json={'user': {'id': 'id-exemplo'}, 'session': None})
    with _client(handler) as client:
        assert not create_user('https://projeto.supabase.co', 'sb_publishable_example',
                               'aluno@example.org', 'SenhaDeTesteExemplo!', client=client)


def test_existing_user_login_verified_in_auth(monkeypatch):
    seen = []
    def handler(request):
        seen.append(request.url.path)
        if request.method == 'POST':
            return httpx.Response(200, json={'access_token': 'x' * 64})
        assert request.headers['Authorization'] == 'Bearer ' + 'x' * 64
        return httpx.Response(200, json={'id': '123', 'email': 'teste@example.org'})
    with _client(handler) as client:
        verify_user('https://projeto.supabase.co', 'sb_publishable_example',
                    'teste@example.org', 'SenhaDeTesteExemplo!', client=client)
    assert seen == ['/auth/v1/token', '/auth/v1/user']


def test_reject_incorrect_email_from_auth():
    def handler(request):
        if request.method == 'POST':
            return httpx.Response(200, json={'access_token': 'x' * 64})
        return httpx.Response(200, json={'id': '123', 'email': 'outra@example.org'})
    with _client(handler) as client:
        with pytest.raises(ConfigError, match='usuário diferente'):
            verify_user('https://projeto.supabase.co', 'sb_publishable_example',
                        'teste@example.org', 'SenhaDeTesteExemplo!', client=client)


def test_env_written_only_on_private_filename(tmp_path):
    example = tmp_path / '.env.example'
    example.write_text('SUPABASE_URL=https://projeto.supabase.co\nTEST_SUPABASE_EMAIL=\nTEST_SUPABASE_PASSWORD=\n', encoding='utf-8')
    dest = tmp_path / '.env'
    save_env({'TEST_SUPABASE_EMAIL': 'teste@example.org',
              'TEST_SUPABASE_PASSWORD': 'exemplo'}, dest=dest, example=example)
    txt = dest.read_text(encoding='utf-8')
    assert 'SUPABASE_URL=https://projeto.supabase.co' in txt
    assert dotenv_values(dest)['TEST_SUPABASE_EMAIL'] == 'teste@example.org'
    assert dotenv_values(dest)['TEST_SUPABASE_PASSWORD'] == 'exemplo'
    with pytest.raises(ConfigError, match='Destino proibido'):
        save_env({'TEST_SUPABASE_EMAIL': 'teste@example.org'}, dest=tmp_path / '.env.example', example=example)


def test_groq_real_api_key_format_is_checked_but_mocked_locally():
    def handler(request):
        assert request.url.host == 'api.groq.com'
        assert request.headers['Authorization'] == 'Bearer gsk_test_fake'
        return httpx.Response(200, json={'data': [{'id': 'modelo-teste'}]})
    with _client(handler) as client:
        validate_groq('gsk_test_fake', client=client)
    with _client(handler) as client:
        with pytest.raises(ConfigError, match='Formato'):
            validate_groq('not-a-groq-key', client=client)

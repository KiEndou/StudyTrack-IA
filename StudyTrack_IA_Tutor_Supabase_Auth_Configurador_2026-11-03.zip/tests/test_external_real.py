"""Três testes externos REAIS. A falta de credenciais causa SKIP explícito.

1. Login de teste via Supabase Auth real
2. Bearer JWT real validado no endpoint FastAPI /tutor/chat
3. Conversa FastAPI -> Supabase Auth -> Groq real

NUNCA colocar credenciais no repositório ou exibi-las nos logs.
"""
import os

import httpx
import pytest
from pathlib import Path
from dotenv import load_dotenv
load_dotenv(Path(__file__).resolve().parents[1] / ".env")
from fastapi.testclient import TestClient

from app.main import app
import app.api.routes.tutor as tutor


def required_vars(*names: str) -> dict[str, str]:
    missing = [name for name in names if not os.environ.get(name)]
    if missing:
        pytest.skip("Sem configuração privada para teste real: " + ", ".join(missing))
    return {name: os.environ[name] for name in names}


def authenticate_real() -> str:
    cfg = required_vars(
        "SUPABASE_URL", "SUPABASE_PUBLISHABLE_KEY",
        "TEST_SUPABASE_EMAIL", "TEST_SUPABASE_PASSWORD",
    )
    with httpx.Client(timeout=20) as client:
        response = client.post(
            f"{cfg['SUPABASE_URL'].rstrip('/')}/auth/v1/token?grant_type=password",
            headers={"apikey": cfg["SUPABASE_PUBLISHABLE_KEY"]},
            json={"email": cfg["TEST_SUPABASE_EMAIL"], "password": cfg["TEST_SUPABASE_PASSWORD"]},
        )
    assert response.status_code == 200, f"Supabase Auth HTTP {response.status_code}"
    token = response.json().get("access_token")
    assert token, "Supabase Auth não retornou JWT de acesso."
    return token


def test_01_supabase_login_real():
    token = authenticate_real()
    assert len(token) > 20


def test_02_valid_jwt_protects_tutor_real(monkeypatch):
    token = authenticate_real()

    # O provedor de IA é substituído APENAS neste teste, que avalia autenticação real.
    async def artificial_response(_message, _history):
        return "Resposta isolada para teste de autenticação real"
    monkeypatch.setattr(tutor, "ask_groq", artificial_response)
    result = TestClient(app).post(
        "/api/tutor/chat",
        headers={"Authorization": f"Bearer {token}"},
        json={"message": "Teste protegido"},
    )
    assert result.status_code == 200, f"Rota protegida HTTP {result.status_code}"
    assert result.json()["reply"] == "Resposta isolada para teste de autenticação real"


def test_03_groq_full_pipeline_real():
    required_vars("GROQ_API_KEY")
    token = authenticate_real()
    result = TestClient(app).post(
        "/api/tutor/chat",
        headers={"Authorization": f"Bearer {token}"},
        json={"message": "Em uma frase, defina algoritmo de busca em largura."},
    )
    assert result.status_code == 200, f"Integração Groq HTTP {result.status_code}"
    data = result.json()
    assert isinstance(data.get("reply"), str) and data["reply"].strip()
    assert data.get("model")

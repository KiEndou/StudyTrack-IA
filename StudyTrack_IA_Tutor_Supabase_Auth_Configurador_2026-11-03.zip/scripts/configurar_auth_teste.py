"""Configura, de forma privada, conta de teste Supabase Auth e chave Groq.

Uso, na raiz do projeto:
    python -m pip install -r backend/requirements-dev.txt
    python scripts/configurar_auth_teste.py

NUNCA copie o .env gerado para ZIP, chat ou repositório Git.
"""
from __future__ import annotations

import getpass
import json
import os
from pathlib import Path
import re
import sys
import tempfile
from typing import Any

import httpx
from dotenv import dotenv_values

ROOT = Path(__file__).resolve().parents[1]
ENV_FILE = ROOT / ".env"
EXAMPLE_FILE = ROOT / ".env.example"


class ConfigError(Exception):
    """Falha de configuração ou autenticação exibível sem segredos."""


def current_settings(env_file: Path = ENV_FILE, example_file: Path = EXAMPLE_FILE) -> dict[str, str]:
    """Lê opções públicas sem exibir credenciais privadas."""
    values: dict[str, str] = {}
    for path in (example_file, env_file):
        if path.exists():
            values.update({k: str(v) for k, v in dotenv_values(path).items() if v is not None})
    return {**values, **{k: v for k, v in os.environ.items() if k in (
        "SUPABASE_URL", "SUPABASE_PUBLISHABLE_KEY", "GROQ_API_KEY"
    )}}


def redact_error(response: httpx.Response, service: str) -> ConfigError:
    """Não inclui payloads arbitrários nem headers com segredos em erros."""
    body: dict[str, Any] = {}
    try:
        obj = response.json()
        if isinstance(obj, dict):
            body = obj
    except (ValueError, TypeError):
        pass
    known_codes = ("email_not_confirmed", "invalid_credentials", "email_exists", "over_email_send_rate_limit", "user_already_exists")
    code = body.get("code", "")
    if code not in known_codes:
        code = "erro_de_autenticacao" if service == "Supabase" else "erro_api"
    return ConfigError(f"{service}: HTTP {response.status_code}, código {code}.")


def supabase_request(
    base: str, publishable_key: str, route: str, payload: dict[str, str],
    *, client: httpx.Client,
) -> dict[str, Any]:
    if not base.startswith("https://"):
        raise ConfigError("SUPABASE_URL deve usar HTTPS.")
    if not publishable_key:
        raise ConfigError("SUPABASE_PUBLISHABLE_KEY não configurada.")
    response = client.post(
        f"{base.rstrip('/')}/auth/v1/{route}",
        headers={"apikey": publishable_key, "Content-Type": "application/json"},
        json=payload,
    )
    if response.status_code >= 400:
        raise redact_error(response, "Supabase")
    obj = response.json()
    if not isinstance(obj, dict):
        raise ConfigError("Supabase retornou resposta inesperada.")
    return obj


def create_user(base: str, key: str, email: str, password: str, *, client: httpx.Client) -> bool:
    """SignUp oficial. True apenas se sessão imediata foi retornada."""
    result = supabase_request(base, key, "signup", {"email": email, "password": password}, client=client)
    if not result.get("user"):
        raise ConfigError("Cadastro não retornou usuário; confira Supabase Authentication.")
    return bool(result.get("access_token"))


def verify_user(base: str, key: str, email: str, password: str, *, client: httpx.Client) -> None:
    """Confirma login real e consulta /auth/v1/user; não registra tokens em arquivo."""
    result = supabase_request(
        base, key, "token?grant_type=password", {"email": email, "password": password}, client=client
    )
    token = result.get("access_token")
    if not isinstance(token, str) or len(token) < 20:
        raise ConfigError("Login não retornou token de sessão válido.")
    response = client.get(
        f"{base.rstrip('/')}/auth/v1/user",
        headers={"apikey": key, "Authorization": f"Bearer {token}"},
    )
    if response.status_code != 200:
        raise redact_error(response, "Supabase")
    details = response.json()
    if not isinstance(details, dict) or not details.get("id") or str(details.get("email", "")).casefold() != email.casefold():
        raise ConfigError("Supabase retornou um usuário diferente do informado.")


def validate_groq(api_key: str, *, client: httpx.Client) -> None:
    if not api_key or not api_key.startswith("gsk_"):
        raise ConfigError("Formato de chave Groq inesperado; confirme a chave no console Groq.")
    response = client.get(
        "https://api.groq.com/openai/v1/models",
        headers={"Authorization": f"Bearer {api_key}"},
    )
    if response.status_code != 200:
        raise redact_error(response, "Groq")
    body = response.json()
    if not isinstance(body, dict) or not isinstance(body.get("data"), list):
        raise ConfigError("Groq retornou resposta inesperada; chave não foi salva.")


def save_env(values: dict[str, str], *, dest: Path = ENV_FILE, example: Path = EXAMPLE_FILE) -> None:
    """Atualiza ou acrescenta somente chaves indicadas e evita salvar segredos em arquivos públicos."""
    if dest.name != ".env":
        raise ConfigError("Destino proibido: as credenciais devem ser salvas somente em .env.")
    source = dest.read_text(encoding="utf-8") if dest.exists() else (
        example.read_text(encoding="utf-8") if example.exists() else ""
    )
    for name, value in values.items():
        if not re.fullmatch(r"[A-Z][A-Z0-9_]*", name):
            raise ConfigError("Nome de variável inválido.")
        if not value or any(c in value for c in "\r\n\0"):
            raise ConfigError(f"Valor não permitido em {name}.")
        # Aspas escapadas para preservar senhas com espaços, # e caracteres especiais.
        replacement = f"{name}={json.dumps(value, ensure_ascii=False)}"
        expr = re.compile(r"(?m)^" + re.escape(name) + r"\s*=.*$")
        if expr.search(source):
            source = expr.sub(lambda _m: replacement, source)
        else:
            source = source.rstrip("\n") + "\n" + replacement + "\n"
    dest.parent.mkdir(parents=True, exist_ok=True)
    fd, tmpname = tempfile.mkstemp(prefix=".env-", dir=dest.parent)
    try:
        try:
            os.fchmod(fd, 0o600)
        except (AttributeError, OSError):
            pass  # Windows usa ACLs da pasta atual.
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as f:
            f.write(source)
        verified = dotenv_values(tmpname)
        if any(verified.get(k) != v for k, v in values.items()):
            raise ConfigError("Uma credencial contém caracteres não suportados no .env. Use outro valor.")
        os.replace(tmpname, dest)
    finally:
        if os.path.exists(tmpname):
            os.unlink(tmpname)


def ask_credentials() -> tuple[str, str]:
    email = input("Email de teste (precisa acessar a caixa de entrada): ").strip().lower()
    if not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", email):
        raise ConfigError("Informe um endereço de email válido, ao qual você tenha acesso.")
    password = getpass.getpass("Senha da conta de teste (não aparece na tela): ")
    if len(password) < 8 or len(password) > 128:
        raise ConfigError("Use uma senha de 8 a 128 caracteres.")
    if any(c in password for c in "\r\n\0"):
        raise ConfigError("A senha não pode conter quebra de linha ou caractere nulo.")
    return email, password


def setup_groq(*, client: httpx.Client) -> None:
    print("\nGroq: deixe vazio caso ainda não tenha a chave (não será gravada).")
    key = getpass.getpass("GROQ_API_KEY: ").strip()
    if not key:
        print("Groq não configurada nesta execução.")
        return
    validate_groq(key, client=client)
    save_env({"GROQ_API_KEY": key})
    print("Chave Groq validada na API e registrada somente no .env privado.")


def main() -> int:
    print("StudyTrack IA | Configurador privado de testes Supabase Auth/Groq")
    print("Nenhuma senha ou chave será exibida. Não envie .env ou inclua-o no ZIP.")
    cfg = current_settings()
    base = cfg.get("SUPABASE_URL", "")
    key = cfg.get("SUPABASE_PUBLISHABLE_KEY", "")
    print("1 - Utilizar e validar conta existente do Supabase Auth")
    print("2 - Criar conta de teste usando o cadastro oficial Supabase Auth")
    print("3 - Configurar somente a chave Groq")
    mode = input("Escolha [1/2/3]: ").strip()
    try:
        with httpx.Client(timeout=25) as client:
            if mode == "3":
                setup_groq(client=client)
                return 0
            if mode not in ("1", "2"):
                raise ConfigError("Opção inválida.")
            email, password = ask_credentials()
            if mode == "2":
                # Não modifica auth.users via SQL: signup aciona fluxos oficiais.
                session_created = create_user(base, key, email, password, client=client)
                if not session_created:
                    print("Cadastro enviado. Confirme o email recebido antes de tentar login.")
                    print("Depois execute novamente e escolha a opção 1.")
                    return 0
            verify_user(base, key, email, password, client=client)
            save_env({
                "SUPABASE_URL": base,
                "SUPABASE_PUBLISHABLE_KEY": key,
                "TEST_SUPABASE_EMAIL": email,
                "TEST_SUPABASE_PASSWORD": password,
            })
            print("Login real Supabase validado; credenciais gravadas no .env privado.")
            setup_groq(client=client)
            print("Agora: $env:PYTHONPATH = 'backend'; python -m pytest -q tests/test_external_real.py -rs")
            return 0
    except (httpx.HTTPError, ValueError) as exc:
        print(f"Falha de conexão ou resposta inesperada: {type(exc).__name__}. Confirme rede e configuração.", file=sys.stderr)
        return 1
    except ConfigError as exc:
        print(f"Configuração não concluída: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
